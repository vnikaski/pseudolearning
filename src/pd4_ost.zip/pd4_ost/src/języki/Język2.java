package języki;

public class Język2 extends Język {
    public Język2(){
        super.nazwa = "polski";
        super.literyAlfabetu = "aąbcćdeęfghijklłmnńoóprsśtuwyzźż";
    }
}
