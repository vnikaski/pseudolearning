package generatory;

public interface GenerowaniePoLiterze {
    public String wygenerujPoLiterze(String poprzedzająca);
}
